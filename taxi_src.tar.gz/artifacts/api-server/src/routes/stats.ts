import { Router, type IRouter } from "express";
import { db, jobsTable, companiesTable } from "@workspace/db";
import { sql, count } from "drizzle-orm";

const router: IRouter = Router();

router.get("/stats", async (_req, res): Promise<void> => {
  const [jobs] = await db.select({ total: count() }).from(jobsTable);
  const [companies] = await db.select({ total: count() }).from(companiesTable);
  const [stage1] = await db
    .select({ total: count() })
    .from(companiesTable)
    .where(sql`${companiesTable.status} = 'STAGE1_DONE'`);
  const [stage2] = await db
    .select({ total: count() })
    .from(companiesTable)
    .where(sql`${companiesTable.status} = 'STAGE2_DONE'`);
  const [generating] = await db
    .select({ total: count() })
    .from(companiesTable)
    .where(
      sql`${companiesTable.status} IN ('STAGE1_GENERATING', 'STAGE2_GENERATING')`
    );

  res.json({
    totalJobs: jobs?.total ?? 0,
    totalCompanies: companies?.total ?? 0,
    stage1Done: stage1?.total ?? 0,
    stage2Done: stage2?.total ?? 0,
    generating: generating?.total ?? 0,
  });
});

export default router;
